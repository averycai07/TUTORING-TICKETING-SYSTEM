export const BG_COLOR_SECONDATY = "#004d71";
